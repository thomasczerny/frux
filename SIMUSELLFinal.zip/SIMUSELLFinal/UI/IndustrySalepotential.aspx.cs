

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;
#region Amendament History

/// <summary>

/// Project : SIM U SELL

/// Purpose of Form: Industry Sales Potential

/// Working Task : Binding report of Management Decission

/// Developer : Srikanth

/// Date : 24-07-2017

/// Store Procedures : getSimulation,getSimulationRound,getTeambySimulation

/// Tables Used: td_saleRepDetPRounds,td_CompanyDet,td_Simulation,td_Instructor,td_CompanyStudents,td_SimulationRoundsDet,tr_TerritoryStateDet,tm_state

/// </summary>
#endregion
public partial class frmProjectMaster : System.Web.UI.Page
{
    /// <summary>
    /// General Class file calling
    /// </summary>
    General gen = new General();

    int AAccount = 0, BAccount = 0, CAccount = 0, TTotal = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session.Count <= 0)
        {
            Response.Redirect("~/Login.aspx");
        }
        if (!IsPostBack)
        {
            #region Get Simulations details by Instructor ID
            getSimulation();
            #endregion
            BtnCancel0.Visible = false;
            //   Fillgrid();

        }


    }

    protected void Fillgrid()
    {

        DataSet ds = new DataSet();

        ds = gen.getIndustrySalePotential(ddlSimulationName.SelectedValue, ddlSimulationRound.SelectedValue, ddlTeam.SelectedValue);

        if (ds.Tables[0].Rows.Count > 0)
        {

            grdDetails.DataSource = ds.Tables[0];
            grdDetails.DataBind();
            //  BindGrid(ds.Tables[0], true);
            BtnCancel0.Visible = true;

        }
        else
        {

            grdDetails.DataSource = null;
            grdDetails.DataBind();
            BtnCancel0.Visible = false;


        }





    }

   
    protected void getSimulation()
    {

        DataSet dsn = new DataSet();
        dsn = gen.getSimulation(Session["uid"].ToString().Trim(), Session["userlevel"].ToString().Trim());
        if (dsn.Tables[0].Rows.Count > 0)
        {


            ddlSimulationName.DataSource = dsn.Tables[0];
            ddlSimulationName.DataValueField = "simulationID";
            ddlSimulationName.DataTextField = "simulationName";
            ddlSimulationName.DataBind();
            ddlSimulationName.Items.Insert(0, "Select");


        }




    }

    protected void getSimulationRound(string simulationID)
    {

        DataSet dsn = new DataSet();
        dsn = gen.getSimulationRound(ddlSimulationName.SelectedValue);
        if (dsn.Tables[0].Rows.Count > 0)
        {


            ddlSimulationRound.DataSource = dsn.Tables[0];
            ddlSimulationRound.DataValueField = "simulationRoundId";
            ddlSimulationRound.DataTextField = "RoundNo";
            ddlSimulationRound.DataBind();
            ddlSimulationRound.Items.Insert(0, "Select");


        }




    }

    protected void getTeambySimulation(string simulationID)
    {

        DataSet dsn = new DataSet();
        dsn = gen.getTeambySimulation(ddlSimulationName.SelectedValue);
        if (dsn.Tables[0].Rows.Count > 0)
        {


            ddlTeam.DataSource = dsn.Tables[0];
            ddlTeam.DataValueField = "companyID";
            ddlTeam.DataTextField = "companyName";
            ddlTeam.DataBind();
            ddlTeam.Items.Insert(0, "Select");


        }




    }

   
    protected void grdDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            AssignGridRowStyle(e.Row, "text-left");
            int AAccount1 = Convert.ToInt32((e.Row.Cells[2].Text.Trim() == "" ? "0" : e.Row.Cells[2].Text));
            AAccount = AAccount1 + AAccount;
            int BAccount1 = Convert.ToInt32((e.Row.Cells[3].Text.Trim() == "" ? "0" : e.Row.Cells[3].Text));
            BAccount = BAccount1 + BAccount;
            int CAccount1 = Convert.ToInt32((e.Row.Cells[4].Text.Trim() == "" ? "0" : e.Row.Cells[4].Text));
            CAccount = CAccount1 + CAccount;
            int  TTotal1 = Convert.ToInt32((e.Row.Cells[5].Text.Trim() == "" ? "0" : e.Row.Cells[5].Text));
            TTotal = TTotal1 + TTotal;
        }

         if (e.Row.RowType == DataControlRowType.Header)
        {
            int index = e.Row.Cells.Count;
            if (index >= 1)
            {
                for (int cellIndex = 0; cellIndex < e.Row.Cells.Count; cellIndex++) e.Row.Cells[cellIndex].CssClass = "text-right";

            }
            e.Row.Cells[0].CssClass = "text-left";

            e.Row.Cells[1].CssClass = "text-left";
        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            e.Row.Cells[1].Text = "Total";
            e.Row.Cells[2].Text = AAccount.ToString();
            e.Row.Cells[3].Text = BAccount.ToString();
            e.Row.Cells[4].Text = CAccount.ToString();
            e.Row.Cells[5].Text = TTotal.ToString();
        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            int index = e.Row.Cells.Count;
            if (index >= 1)
            {
                for (int cellIndex = 0; cellIndex < e.Row.Cells.Count; cellIndex++) e.Row.Cells[cellIndex].CssClass = "text-right";

            }
            e.Row.Cells[0].CssClass = "text-left";

          //  e.Row.Cells[1].CssClass = "text-left";
        }
    }

    private void AssignGridRowStyle(GridViewRow gr, string cssName)
    {
        try
        {
            if (gr.RowType == DataControlRowType.Header)
            {
                for (int cellIndex = 0; cellIndex < gr.Cells.Count; cellIndex++) gr.Cells[cellIndex].CssClass = cssName;
            }
            else if (gr.RowType == DataControlRowType.Footer)
            {
                gr.CssClass = cssName;

                for (int cellIndex = 0; cellIndex < gr.Cells.Count; cellIndex++)
                {
                    gr.Cells[cellIndex].CssClass = cssName;

                    try
                    {
                        double d;
                        if (Double.TryParse(gr.Cells[cellIndex].Text, out d)) gr.Cells[cellIndex].CssClass = "text-right";
                    }
                    catch (Exception) { }
                }
            }
            else
            {
                gr.CssClass = cssName;

                for (int cellIndex = 0; cellIndex < gr.Cells.Count; cellIndex++)
                {
                    gr.Cells[cellIndex].CssClass = cssName;

                    try
                    {
                        double d;

                        if (Double.TryParse(gr.Cells[cellIndex].Text, out d)) gr.Cells[cellIndex].CssClass = "text-right";
                    }
                    catch (Exception) { }
                }
            }
        }
        catch (Exception) { }
    }


   
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("IndustrySalepotential.aspx");
    }
    protected void ddlSimulationName_SelectedIndexChanged(object sender, EventArgs e)
    {

        getSimulationRound(ddlSimulationName.SelectedValue);


        getTeambySimulation(ddlSimulationName.SelectedValue);

    }
    protected void BtnSubmit_Click(object sender, EventArgs e)
    {
        Fillgrid();
    }

    protected void ExportToExcel()
    {
        try
        {
            Response.Clear();
            Response.Buffer = true;
            Response.ClearContent();
            Response.ClearHeaders();
            Response.Charset = "";
            string FileName = "Industry Sales Potential" + DateTime.Now + ".xls";
            StringWriter strwritter = new StringWriter();
            HtmlTextWriter htmltextwrtter = new HtmlTextWriter(strwritter);
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = "application/vnd.ms-excel";
            Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName);
            grdDetails.GridLines = GridLines.Both;
            grdDetails.HeaderStyle.Font.Bold = true;
            grdDetails.RenderControl(htmltextwrtter);
            Response.Write(strwritter.ToString());
            Response.End();
        }
        catch (Exception e)
        {

        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
    }
    protected void BtnCancel0_Click(object sender, ImageClickEventArgs e)
    {
        ExportToExcel();
    }
}
