

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class frmProjectMaster : System.Web.UI.Page
{
    General gen = new General();
    string NOC_File_Path, NOC_File_Type, NOC_File_Name;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            getSimulation();

         //   Fillgrid();

        }

       
    }

    void Fillgrid()
    {

        DataSet ds = new DataSet();

        ds = gen.getInsutryPerformance(ddlSimulationName.SelectedValue, ddlSimulationRound.SelectedValue);

        if (ds.Tables[0].Rows.Count > 0)
        {

            grdDetails.DataSource = ds.Tables[0];
            grdDetails.DataBind();
          //  BindGrid(ds.Tables[0], true);

        }
        else
        {
            grdDetails.DataSource = null;
            grdDetails.DataBind();


        }

             



    }

    protected void Convert(object sender, EventArgs e)
    {
        DataTable dt = (DataTable)ViewState["dt"];
       
           
            DataTable dt2 = new DataTable();
            for (int i = 0; i <= dt.Rows.Count; i++)
            {
                dt2.Columns.Add();
            }
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                dt2.Rows.Add();
                dt2.Rows[i][0] = dt.Columns[i].ColumnName;
            }
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                for (int j = 0; j < dt.Rows.Count; j++)
                {
                    dt2.Rows[i][j + 1] = dt.Rows[j][i];
                }
            }
            BindGrid(dt2, true);
        
    }

    private void BindGrid(DataTable dt, bool rotate)
    {
        grdDetails.ShowHeader = !rotate;
        grdDetails.DataSource = dt;
        grdDetails.DataBind();
        if (rotate)
        {
            foreach (GridViewRow row in grdDetails.Rows)
            {
                row.Cells[0].CssClass = "header";
            }
        }
    }
    void getSimulation()
    {

        DataSet dsn = new DataSet();
        dsn = gen.getSimulation(Session["uid"].ToString().Trim(), Session["userlevel"].ToString().Trim());
        if (dsn.Tables[0].Rows.Count > 0)
        {


            ddlSimulationName.DataSource = dsn.Tables[0];
            ddlSimulationName.DataValueField = "simulationID";
            ddlSimulationName.DataTextField = "simulationName";
            ddlSimulationName.DataBind();
            ddlSimulationName.Items.Insert(0, "Select");


        }




    }

    void getSimulationRound(string simulationID)
    {

        DataSet dsn = new DataSet();
        dsn = gen.getSimulationRound(ddlSimulationName.SelectedValue);
        if (dsn.Tables[0].Rows.Count > 0)
        {


            ddlSimulationRound.DataSource = dsn.Tables[0];
            ddlSimulationRound.DataValueField = "simulationRoundId";
            ddlSimulationRound.DataTextField = "RoundNo";
            ddlSimulationRound.DataBind();
            ddlSimulationRound.Items.Insert(0, "Select");


        }




    }

    void getTeambySimulation(string simulationID)
    {

        DataSet dsn = new DataSet();
        dsn = gen.getTeambySimulation(ddlSimulationName.SelectedValue);
        if (dsn.Tables[0].Rows.Count > 0)
        {


            ddlTeam.DataSource = dsn.Tables[0];
            ddlTeam.DataValueField = "companyID";
            ddlTeam.DataTextField = "companyName";
            ddlTeam.DataBind();
            ddlTeam.Items.Insert(0, "Select");


        }




    }
  
    protected void btnEdit_Click(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        

    }
   
    protected void btnReset_Click(object sender, EventArgs e)
    {
        
    }
   
    protected void ddlDeptCode_SelectedIndexChanged1(object sender, EventArgs e)
    {
       
    }
    protected void ddlmandal_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {

        
    }
    protected void ddlSchemes_SelectedIndexChanged(object sender, EventArgs e)
    {
      
    }

    protected void ddlmandal0_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
    protected void ddlSchemeYear0_SelectedIndexChanged(object sender, EventArgs e)
    {
      
    }
    protected void grdDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
          





            //HyperLink h2 = (HyperLink)e.Row.Cells[6].Controls[0];
            //h2.Target = "_blank";
            //h2.NavigateUrl = "FrmViewSimulation.aspx?intApplid=" + Convert.ToString(DataBinder.Eval(e.Row.DataItem, "simulationID")).Trim();// 



        }



    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("IndustryPerformaceAbstract.aspx");
    }
    protected void ddlSimulationName_SelectedIndexChanged(object sender, EventArgs e)
    {
        
            getSimulationRound(ddlSimulationName.SelectedValue);
        
        
            getTeambySimulation(ddlSimulationName.SelectedValue);
        
    }
    protected void BtnSubmit_Click(object sender, EventArgs e)
    {
        Fillgrid();
    }

    protected void ExportToExcel()
    {
        try
        {
            Response.Clear();
            Response.Buffer = true;
            Response.ClearContent();
            Response.ClearHeaders();
            Response.Charset = "";
            string FileName = "Industry Performance Report" + DateTime.Now + ".xls";
            StringWriter strwritter = new StringWriter();
            HtmlTextWriter htmltextwrtter = new HtmlTextWriter(strwritter);
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = "application/vnd.ms-excel";
            Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName);
            grdDetails.GridLines = GridLines.Both;
            grdDetails.HeaderStyle.Font.Bold = true;
            grdDetails.RenderControl(htmltextwrtter);
            Response.Write(strwritter.ToString());
            Response.End();
        }
        catch (Exception e)
        {

        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
    }
    protected void BtnCancel0_Click(object sender, ImageClickEventArgs e)
    {
        ExportToExcel();
    }
}
