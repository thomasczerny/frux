﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

public partial class HomeMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //string url = Path.GetFileName(Request.Url.AbsoluteUri).ToString();
        //if (url.Contains("Login.aspx") == true)
        //{
        //    divLogin.Visible = false;
        //}
    }

    protected void btnHomeSignin_Click(object sender, EventArgs e)
    {
        //Session["username"] = txtUsername.Text;
        //Session["Passward"] = txtPassword.Text;
        //Response.Redirect("~/Login.aspx");

    }
}
