using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;
/// <summary>
/// Project: SIM U SEL
/// Purpose : Modificiation on Team ID Based Process for display and Hire and Fire and Manage Sale person
/// Developer : M.Srikanth
/// Date : 06-07-2017
/// Modified Developer : N.Abhilash
/// Date : 06-07-2017
/// Store Procedures Created: getslaesforcebyIDbyLatTeamID,getverifydescissionstatusteamID,GetProfitAndLoseStatement
/// </summary>
public partial class frmProjectMaster : System.Web.UI.Page
{
    General gen = new General();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            getDashboardStudent();
            //Getdetails();
        }
    }

    private DataTable PivotTable(DataTable origTable)
    {

        DataTable newTable = new DataTable();
        DataRow dr = null;
        //Add Columns to new Table
        for (int i = 0; i <= origTable.Rows.Count; i++)
        {
            newTable.Columns.Add(new DataColumn(origTable.Columns[i].ColumnName, typeof(String)));
        }

        //Execute the Pivot Method
        for (int cols = 0; cols < origTable.Columns.Count; cols++)
        {
            dr = newTable.NewRow();
            for (int rows = 0; rows < origTable.Rows.Count; rows++)
            {
                if (rows < origTable.Columns.Count)
                {
                    dr[0] = origTable.Columns[cols].ColumnName; // Add the Column Name in the first Column
                    dr[rows + 1] = origTable.Rows[rows][cols];
                }
            }
            newTable.Rows.Add(dr); //add the DataRow to the new Table rows collection
        }
        return newTable;
    }
    void getDashboardStudent()
    {
        DataSet Deatils = new DataSet();

        Deatils = gen.getDashboardStudent(Session["userCode"].ToString().Trim());


        if (Deatils.Tables[0].Rows.Count > 0)
        {
            Label4.Text = Deatils.Tables[0].Rows[0]["Name"].ToString();
            Label3.Text = Deatils.Tables[0].Rows[0]["companyName"].ToString();
            Label1.Text = Deatils.Tables[0].Rows[0]["simulationName"].ToString();
            Label5.Text = Deatils.Tables[0].Rows[0]["email"].ToString();
            Label9.Text = Deatils.Tables[0].Rows[0]["Insname"].ToString();
        }
        if (Deatils.Tables[0].Rows.Count > 0)
        {
            ddlRounds.DataSource = Deatils.Tables[1];
            ddlRounds.DataTextField = "RoundNo";
            ddlRounds.DataValueField = "simulationRoundId";
            ddlRounds.DataBind();
            ddlRounds.Items.Insert(0, "--Select--");
        }

    }
    void Getdetails()
    {
        DataSet dsnew = new DataSet();
        dsnew = gen.GetProfitAndLoseStatement(ddlRounds.SelectedValue, "%");
        if (dsnew.Tables[0].Rows.Count > 0)
        {
            DataTable pivotedTable = PivotTable(dsnew.Tables[0]);
            grdProfitLose.DataSource = pivotedTable;
            grdProfitLose.DataBind();
        }
        else
        {
            grdProfitLose.DataSource = null;
            grdProfitLose.DataBind();
        }
    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
    }
    protected void grdProfitLose_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            int index = e.Row.RowIndex;
            if (index != 0)
            {
                AssignGridRowStyle(e.Row, "text-right");

            }

        }
    }

    private void AssignGridRowStyle(GridViewRow gr, string cssName)
    {
        try
        {
            if (gr.RowType == DataControlRowType.Footer)
            {
                gr.CssClass = cssName;

                for (int cellIndex = 0; cellIndex < gr.Cells.Count; cellIndex++)
                {
                    gr.Cells[cellIndex].CssClass = "text-left";

                    try
                    {
                        int d;
                        if (Int32.TryParse(gr.Cells[cellIndex].Text, out d)) gr.Cells[cellIndex].CssClass = cssName;
                    }
                    catch (Exception) { }
                }
            }
            else
            {
                gr.CssClass = cssName;

                for (int cellIndex = 0; cellIndex < gr.Cells.Count; cellIndex++)
                {
                    gr.Cells[cellIndex].CssClass = "text-left";

                    try
                    {
                        double d;

                        if (Double.TryParse(gr.Cells[cellIndex].Text, out d)) gr.Cells[cellIndex].CssClass = cssName;
                    }
                    catch (Exception) { }
                }
            }
            gr.Cells[0].CssClass = "text-left";
        }
        catch (Exception) { }
    }


    protected void ddlRounds_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlRounds.SelectedValue != "--Select--")
        {
            Getdetails();
        }
        else
        {
            grdProfitLose.DataSource = null;
            grdProfitLose.DataBind();
            divFail.Visible = true;
            lblResultF.Text = "Please Select Simulation Round";
        }
    }

    protected void ExportToExcel()
    {
        try
        {
            Response.Clear();
            Response.Buffer = true;
            Response.ClearContent();
            Response.ClearHeaders();
            Response.Charset = "";
            string FileName = "Profit and Loss Statement" + DateTime.Now + ".xls";
            StringWriter strwritter = new StringWriter();
            HtmlTextWriter htmltextwrtter = new HtmlTextWriter(strwritter);
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = "application/vnd.ms-excel";
            Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName);
            grdProfitLose.GridLines = GridLines.Both;
            grdProfitLose.HeaderStyle.Font.Bold = true;
            grdProfitLose.RenderControl(htmltextwrtter);
            Response.Write(strwritter.ToString());
            Response.End();
        }
        catch (Exception e)
        {

        }
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
    }
    protected void BtnCancel0_Click(object sender, ImageClickEventArgs e)
    {
        ExportToExcel();
    }
}
