////****** Designed by Abhilash on 13-06-2017 *******////
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class UI_frmVehicleSetup : System.Web.UI.Page
{

    #region Declorations
    General gen = new General();
    DataSet dsGet = new DataSet();
    Decimal Amount;

    Decimal Amount1 = 0;

    #endregion

    #region PageLoad
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            GetBasicDetails();
            fillgrid();
            fillgrid1();
        }
    }
    #endregion

    #region GetBasicDetails
    private void GetBasicDetails()
    {
        dsGet = gen.getDashboardStudent(Session["userCode"].ToString().Trim());

        if (dsGet.Tables[0].Rows.Count > 0)
        {
            lblName.Text = dsGet.Tables[0].Rows[0]["Name"].ToString();
            lblTeamName.Text = dsGet.Tables[0].Rows[0]["companyName"].ToString();
            lblSimulationName.Text = dsGet.Tables[0].Rows[0]["simulationName"].ToString();
            lblEmail.Text = dsGet.Tables[0].Rows[0]["email"].ToString();
            lblInstructorName.Text = dsGet.Tables[0].Rows[0]["Insname"].ToString();
        }
        else
        {
        }
    }
    #endregion

    #region GetData
    private void fillgrid()
    {
        dsGet = gen.GetReportsList(Session["userCode"].ToString().Trim());
        if (dsGet.Tables[0].Rows.Count > 0)
        {
            GrdReports.DataSource = dsGet.Tables[0];
            GrdReports.DataBind();
        }
        else
        {
            GrdReports.DataSource = null;
            GrdReports.DataBind();
        }
    }


    private void fillgrid1()
    {
        dsGet = gen.GetStudentPaidReportdet(Session["userCode"].ToString().Trim());
        if (dsGet.Tables[0].Rows.Count > 0)
        {
            GrdReports0.DataSource = dsGet.Tables[0];
            GrdReports0.DataBind();
        }
        else
        {
            GrdReports0.DataSource = null;
            GrdReports0.DataBind();
        }
    }
    #endregion

    #region GridBinding
    protected void GrdReports_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            HiddenField hdfStudentID = (HiddenField)e.Row.Cells[0].FindControl("hdfStudentID");
            hdfStudentID.Value = Convert.ToString(Session["userCode"].ToString()).Trim();

            HiddenField hdfReportID = (HiddenField)e.Row.Cells[0].FindControl("hdfReportID");
            hdfReportID.Value = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "reportID")).Trim();

        }
    }
    #endregion
    #region payFunction
    protected void BtnPay_Click(object sender, EventArgs e)
    {
        //Button BtnSave = (Button)sender;
        //GridViewRow row = GrdReports.Rows[GrdReports.SelectedIndex];
        //HiddenField hdfStudentID = (HiddenField)row.FindControl("hdfStudentID");
        //HiddenField hdfReportID = (HiddenField)row.FindControl("hdfReportID");
      //  RadioButtonList RadioButtonList = (RadioButtonList)row.FindControl("RadioButtonList12");
        foreach (GridViewRow row2 in GrdReports.Rows)
        {
            RadioButtonList RadioButtonList12 = (RadioButtonList)row2.FindControl("RadioButtonList12");
            HiddenField hdfStudentID = (HiddenField)row2.FindControl("hdfStudentID");
            HiddenField hdfReportID = (HiddenField)row2.FindControl("hdfReportID");
            if (RadioButtonList12.SelectedValue == "Yes")
            {
                int i = gen.insReportsales(hdfStudentID.Value, hdfReportID.Value, row2.Cells[2].Text, "", "1", Session["uid"].ToString().Trim());

                fillgrid();
                fillgrid1();
                lblTotal.Text = "0";
            }
            else
            {
            }
        }
    }
    #endregion
    #region ResetFunction
    protected void BtnReset_Click(object sender, EventArgs e)
    {
        Response.Redirect("studentManagePerform.aspx");
    }
    #endregion
    protected void RadioButtonList12_SelectedIndexChanged(object sender, EventArgs e)
    {
        RadioButtonList RadioButtonList = (RadioButtonList)sender;
        GridViewRow row = (GridViewRow)RadioButtonList.NamingContainer;
        if (RadioButtonList.SelectedItem.ToString() == "Yes")
        {

            lblTotal.Text = Convert.ToDecimal(Convert.ToDecimal(lblTotal.Text) + Convert.ToDecimal(row.Cells[2].Text)).ToString("f0");
        }
        //}
        //lblTotal.Text = Convert.ToString(Amount);
    }
    protected void GrdReports0_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            decimal Amount2 = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "reportCost"));

            Amount1 = Amount2 + Amount1;
            e.Row.Cells[2].Text = Amount2.ToString("f0");

        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            //NoofPayams1, NoofBomas1,TotalWorkProposed1, TotaltobeApproved1, TotalInprogress1, TotalClosed1, 
            //TotalFundsDisbursed1, TotalBeneficiaries1, TotalFemaleBeneficiaries1, TotalWorkDays1;

            e.Row.Cells[1].Text = "Total";
            e.Row.Cells[2].Text = Amount1.ToString("f0");

        }






    }
    protected void GrdReports0_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void BtnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmStudentDashboard.aspx");
    }
}
