using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;
/// <summary>
/// Project: SIM U SEL
/// Purpose : Modificiation on Team ID Based Process for display and Hire and Fire and Manage Sale person
/// Developer : M.Srikanth
/// Date : 06-07-2017
/// Store Procedures Created: getslaesforcebyIDbyLatTeamID,getverifydescissionstatusteamID
/// </summary>
public partial class frmProjectMaster : System.Web.UI.Page
{
    General gen = new General();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString.Count > 0)
            {
                getSimulation();
                
            }
            else
            {
                getSimulation();
            }
        }
    }

    private DataTable PivotTable(DataTable origTable)
    {

        DataTable newTable = new DataTable();
        DataRow dr = null;
        //Add Columns to new Table
        for (int i = 0; i <= origTable.Rows.Count; i++)
        {
            newTable.Columns.Add(new DataColumn(origTable.Columns[i].ColumnName, typeof(String)));
        }

        //Execute the Pivot Method
        for (int cols = 0; cols < origTable.Columns.Count; cols++)
        {
            dr = newTable.NewRow();
            for (int rows = 0; rows < origTable.Rows.Count; rows++)
            {
                if (rows < origTable.Columns.Count)
                {
                    dr[0] = origTable.Columns[cols].ColumnName; // Add the Column Name in the first Column
                    dr[rows + 1] = origTable.Rows[rows][cols];
                }
            }
            newTable.Rows.Add(dr); //add the DataRow to the new Table rows collection
        }
        return newTable;
    }

    void getSimulation()
    {

        DataSet dsn = new DataSet();
        dsn = gen.getSimulationsDecission(Session["uid"].ToString().Trim(), Session["userlevel"].ToString().Trim());
        if (dsn.Tables[0].Rows.Count > 0)
        {


            ddlSimulationName.DataSource = dsn.Tables[0];
            ddlSimulationName.DataValueField = "simulationID";
            ddlSimulationName.DataTextField = "simulationName";
            ddlSimulationName.DataBind();
            ddlSimulationName.Items.Insert(0, "Select");
        }
    }

    void Getdetails()
    {
        DataSet dsnew = new DataSet();
        dsnew = gen.GETQuarterlyCompetitiveRanking(ddlSimulationName.SelectedValue, "%");
        if (dsnew.Tables[0].Rows.Count > 0)
        {
            trProfit.Visible = true;
            grdProfit.DataSource = dsnew.Tables[0];
            grdProfit.DataBind();
        }
        else
        {
            trProfit.Visible = false;
            grdProfit.DataSource = null;
            grdProfit.DataBind();
        }
        if (dsnew.Tables[1].Rows.Count > 0)
        {
            trRevenue.Visible = true;
            grdRevenue.DataSource = dsnew.Tables[1];
            grdRevenue.DataBind();
        }
        else
        {
            trRevenue.Visible = false;
            grdRevenue.DataSource = null;
            grdRevenue.DataBind();
        }
    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
    }
    protected void grdProfit_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            for (int i = 1; i < e.Row.Cells.Count - 1; i++)
            {
                if (Convert.ToInt32(e.Row.Cells[i + 1].Text) > Convert.ToInt32(e.Row.Cells[i].Text))
                {
                    e.Row.Cells[i + 1].BackColor = System.Drawing.Color.Red;
                }
                else if (Convert.ToInt32(e.Row.Cells[i + 1].Text) < Convert.ToInt32(e.Row.Cells[i].Text))
                {
                    e.Row.Cells[i + 1].BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    e.Row.Cells[i + 1].BackColor = System.Drawing.Color.White;
                }
            }



        }
    }

    protected void grdRevenue_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            for (int i = 1; i < e.Row.Cells.Count - 1; i++)
            {
                if (Convert.ToInt32(e.Row.Cells[i + 1].Text) > Convert.ToInt32(e.Row.Cells[i].Text))
                {
                    e.Row.Cells[i + 1].BackColor = System.Drawing.Color.Red;
                }
                else if (Convert.ToInt32(e.Row.Cells[i + 1].Text) < Convert.ToInt32(e.Row.Cells[i].Text))
                {
                    e.Row.Cells[i + 1].BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    e.Row.Cells[i + 1].BackColor = System.Drawing.Color.White;
                }
            }
        }
    }

    protected void ddlRounds_SelectedIndexChanged(object sender, EventArgs e)
    {
        //if (ddlRounds.SelectedValue != "--Select--")
        //{
        //    Getdetails();
        //}
        //else
        //{
        //    grdProfitLose.DataSource = null;
        //    grdProfitLose.DataBind();
        //    lblResult.Text = "Please Select Simulation Round";
        //}
    }
    protected void ddlSimulationName_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlSimulationName.SelectedValue != "Select")
        {
            Getdetails();
        }
        else
        {
            trRevenue.Visible = false;
            grdRevenue.DataSource = null;
            grdRevenue.DataBind();
            trProfit.Visible = false;
            grdProfit.DataSource = null;
            grdProfit.DataBind();
        }
    }
}
