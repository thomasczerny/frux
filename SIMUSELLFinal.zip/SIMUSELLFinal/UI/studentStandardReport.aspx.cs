////****** Designed by Ravichandra on 20-08-2012 *******////
//Stored Procedures:getUserByUserId,saveUserRecord,getAllDept,insertemployee by Balkrishna on 25-9-12
//Last modified by Jyotshna on 28-05-2013

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class studentStandardReport : System.Web.UI.Page
{
    #region Declaration
    DB.DB con1 = new DB.DB();
    Employee d = new Employee();
    General gen = new General();
    WMS tran1 = new WMS();
    //DataRow dr;
    //static int id;
    SqlDataReader drHeads = null;
    fruxFunctions fss = new fruxFunctions();
    #endregion

    //Added by Balakrishna on 25-9-12
    int User_Code;
    #region PageLoad
    protected void Page_Load(object sender, EventArgs e)
    {
        //btnOrgLookup.Attributes.Add("onclick", "javascript:return OpenPopup()");
        //lblResult.Text = "";
        if (!Page.IsPostBack)
        {
            DataSet dsnew = new DataSet();

            dsnew = gen.getDashboardStudent(Session["userCode"].ToString().Trim());

            if (dsnew.Tables[0].Rows.Count > 0)
            {


                lblName.Text = dsnew.Tables[0].Rows[0]["Name"].ToString();
                lblTeamName.Text = dsnew.Tables[0].Rows[0]["companyName"].ToString();
                lblSimulationName.Text = dsnew.Tables[0].Rows[0]["simulationName"].ToString();
                lblEmail.Text = dsnew.Tables[0].Rows[0]["email"].ToString();
                lblInstructorName.Text = dsnew.Tables[0].Rows[0]["Insname"].ToString();


            }
            else
            {


            }

        }
        if (Session.Count == 0)
        {
            Response.Redirect("../IndexNew.aspx");
        }
        //else
        //{

        //    if (hdfID.Value.Trim() != "" && hdfFlagID.Value == "0")
        //    {


        //        filldetails();
        //        BtnSubmit.Visible = true;
        //        BtnSubmit.Text = "Update";

        //    }
        //}
        //BtnUpdate.Visible = false;
        //if (Session.Count == 0)
        //{
        //    Response.Redirect("../IndexNew.aspx");
        //}
        //else
        //{
        //    if (!Page.IsPostBack)
        //    {
        //        fiildepartment();
        //        fiildesgnation();
        //    }

        //}

    }
    #endregion

    //#region 
    ////public void fiildepartment()
    ////{
    ////    DataSet ds = new DataSet();

    ////    ds = d.Fetchmandal();
    ////    ddlLocality.DataSource = ds.Tables[0];
    ////    ddlLocality.DataTextField = "dept_name";
    ////    ddlLocality.DataValueField = "intDepartmentid";
    ////    ddlLocality.DataBind();
    ////    ddlLocality.Items.Insert(0, "--Select--");
    ////}
    ////public void fiildesgnation()
    ////{
    ////    DataSet ds = new DataSet();
    ////    ds = d.Fetcdesgnation();
    ////    ddldesignation.DataSource = ds.Tables[0];
    ////    ddldesignation.DataTextField = "desig_name";
    ////    ddldesignation.DataValueField = "intDesignationid";
    ////    ddldesignation.DataBind();
    ////    ddldesignation.Items.Insert(0, "--Select--");
    ////}
    //#endregion 


    //public void BindDepartment()
    //{
    //    ddlLocality.DataSource = (new Department()).getAllDepartment();
    //    ddlLocality.DataTextField = "dept_name";
    //    ddlLocality.DataValueField = "intDepartmentid";
    //    ddlLocality.DataBind();
    //    ddlLocality.Items.Insert(0, "--Select--");
    //}
    //#region BtnSubmit_Click
    //protected void BtnSubmit_Click(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        //User objUsers = (new User()).getUsersByID(txtuserid.Text);
    //        //if (objUsers == null)
    //        //{
    //            //d.emp_name = txtname.Text;
    //            //d.deptid = Convert.ToInt32(ddlLocality.SelectedValue.Trim());
    //            //d.desigid = Convert.ToInt32(ddldesignation.SelectedValue.Trim());
    //            ////d.emp_no =Convert.ToString(DBNull.Value);
    //            ////d.emp_no = "";
    //            //d.mobile_no = txtmobilenumber.Text;
    //            //d.email = txtemail.Text;
    //            //d.work_from = fss.convertDateIndia(txtworkingfrom.Text);
    //            //d.emplevel = char.Parse(ddlUserlevel.SelectedValue);
    //            //d.created_by = Convert.ToInt32(Session["uid"].ToString());
    //            if (BtnSubmit.Text == "Submit")
    //            {
    //                if (txtpwd.Text != txtpwd0.Text)
    //                {
    //                    lblResult.Text = "Password should be same";
    //                    return;
    //                }

    //                User objUsers = (new User()).getUsersByID(txtuserid.Text);
    //                if (objUsers == null)
    //                {

    //                    d.emp_name = txtname.Text;
    //                    d.deptid = Convert.ToInt32(ddlLocality.SelectedValue.Trim());
    //                    d.desigid = Convert.ToInt32(ddldesignation.SelectedValue.Trim());
    //                    //d.emp_no =Convert.ToString(DBNull.Value);
    //                    //d.emp_no = "";
    //                    d.mobile_no = txtmobilenumber.Text;
    //                    d.email = txtemail.Text;
    //                   // d.work_from = fss.convertDateIndia(txtworkingfrom.Text);
    //                  //  d.emplevel = char.Parse(ddlUserlevel.SelectedValue);
    //                    d.created_by = Convert.ToInt32(Session["uid"].ToString());

    //                    int empid = d.SaveRecord();
    //                    //if (result < 0)
    //                    //    lblResult.Text = "inserted successfully.......";
    //                    //txtname.Text = "";
    //                    //ddldesignation.SelectedIndex = 0;
    //                    //ddlLocality.SelectedIndex = 0;
    //                    //txtmobilenumber.Text = "";
    //                    //txtemail.Text = "";
    //                    //txtworkingfrom.Text = "";
    //                    objUsers = new User();
    //                    objUsers.Created_by = User_Code;
    //                    objUsers.User_name = txtname.Text;
    //                    objUsers.Password = txtpwd.Text;
    //                    objUsers.Status = 'Y';

    //                    objUsers.User_Code = empid.ToString();
    //                    objUsers.User_id = txtuserid.Text;
    //                    objUsers.User_level = 2;
    //                    objUsers.User_Type = "EMP";
    //                    objUsers.Created_by = Convert.ToInt32(Session["uid"]);


    //                        objUsers.SaveRecord();

    //                    lblResult.Text = "Employee Registered Successsfully";
    //                    //Jyotshna On 28-05-2013
    //                    string msgs = "Dear <b>" + txtname.Text + "</b>, <br><br> ";
    //                    msgs = msgs + "You are being provided with a login id and password <br><br>";
    //                    msgs = msgs + "<b>Username:</b> " + txtuserid.Text + "<br><b>Password:</b> " + txtpwd.Text + "<br><br><br><br>Regards,<br>" + "ITDA-Seethampeta Project Management System";
    //                    fss.sendMail(txtemail.Text, "fruxinfo@gmail.com", "frux@2013", "ITDA-Seethampeta Project Management System", "ITDA-Seethampeta Project Management System - User Registration", "smtp.gmail.com", msgs, "587");

    //                }
    //                else
    //                {
    //                    lblResult.Text = "User Id Exists....";
    //                    txtuserid.Text = " ";
    //                    txtuserid.Focus();
    //                    //Jytotshna On 28-05-2013
    //                    return;
    //                    //Jytotshna On 28-05-2013
    //                }
    //                ddlLocality.Items.Clear();
    //                BindDepartment();
    //                ddldesignation.Items.Clear();
    //                ddldesignation.Items.Add("--Select--");
    //                txtname.Text = " ";
    //                txtmobilenumber.Text = " ";
    //               // ddlUserlevel.SelectedIndex = 0;
    //                txtuserid.Text = " ";
    //                txtpwd.Text = " ";
    //                txtemail.Text = " ";
    //               // txtworkingfrom.Text = " ";
    //            }

    //            else
    //            {
    //                //d.empid = Convert.ToInt32(hdfID.Value.Trim());
    //                //d.emp_name = txtname.Text;
    //                //d.deptid = Convert.ToInt32(ddlLocality.SelectedValue);
    //                //d.desigid = Convert.ToInt32(ddldesignation.SelectedValue);
    //                ////d.emp_no = "";
    //                //d.mobile_no = txtmobilenumber.Text;
    //                //d.email = txtemail.Text;
    //                //d.work_from = fss.convertDateIndia(txtworkingfrom.Text);
    //                //d.created_by = Convert.ToInt32(Session["uid"].ToString());

    //                if (BtnSubmit.Text == "Update")
    //                {
    //                    d.empid = Convert.ToInt32(hdfID.Value.Trim());
    //                    d.emp_name = txtname.Text;
    //                    d.deptid = Convert.ToInt32(ddlLocality.SelectedValue);
    //                    d.desigid = Convert.ToInt32(ddldesignation.SelectedValue);
    //                    //d.emp_no = "";
    //                    d.mobile_no = txtmobilenumber.Text;
    //                    d.email = txtemail.Text;
    //                  //  d.work_from = fss.convertDateIndia(txtworkingfrom.Text);
    //                    d.created_by = Convert.ToInt32(Session["uid"].ToString());
    //                    d.UpdateRecord();
    //                    lblResult.Text = "Employee updated Successsfully";
    //                    txtname.Text = "";
    //                    ddlLocality.SelectedIndex = 0;
    //                 //  ddldesignation.SelectedIndex = 0;
    //                    ddldesignation.Items.Clear();
    //                    ddldesignation.Items.Add("--Select--");

    //                    txtmobilenumber.Text = "";
    //                    txtemail.Text = "";
    //                  //  txtworkingfrom.Text = "";
    //                    BtnSubmit.Text = "Submit";
    //                   // ddlUserlevel.Enabled = true;
    //                    txtuserid.Enabled = true;
    //                    txtuserid.Text = " ";
    //                    txtpwd.Enabled = true;
    //                    txtpwd.Text = " ";
    //                  //  RequiredFieldValidator10.Enabled = true;
    //                    RequiredFieldValidator8.Enabled = true;
    //                    RequiredFieldValidator9.Enabled = true;

    //                }
    //            }
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //}
    //#endregion 

    //#region filldetails
    //protected void filldetails()
    //{
    //    hdfFlagID.Value = "1";
    //    try
    //    {

    //        DataSet ds = new DataSet();

    //        ds = gen.Fetdetailsinfornt(hdfID.Value.ToString(), HiddenDesig.Value.ToString());

    //       // con1.OpenConnection();
    //       //// drHeads = d.getEmployeeDetails(hdfID.Value.ToString(), HiddenDesig.Value.ToString(), con1.GetConnection);
    //       // DataSet ds = new DataSet();
    //       // ds = d.Fetdetailsinfornt(hdfID.Value.ToString(), HiddenDesig.Value.ToString(), con1.GetConnection);
    //       // while (drHeads.Read())
    //        ddlLocality.SelectedValue = ds.Tables[0].Rows[0]["intDepartmentid"].ToString();
    //        ddldesignation.SelectedValue = ds.Tables[0].Rows[0]["intdesid"].ToString();
    //        txtname.Text = ds.Tables[0].Rows[0]["designame"].ToString();
    //        txtmobilenumber.Text = ds.Tables[0].Rows[0]["mobile_no"].ToString();
    //        txtemail.Text = ds.Tables[0].Rows[0]["email"].ToString();
    //        //{
    //        //    //if (drHeads["intDepartmentid"].ToString() != "")
    //        //    //{
    //        //    //    ddlLocality.SelectedValue = drHeads["intDepartmentid"].ToString();
    //        //    //}
    //        //    //if (ddlLocality.SelectedValue == "--Select--")
    //        //    //{
    //        //    //    ddldesignation.Items.Clear();
    //        //    //    ddldesignation.Items.Insert(0, "--Select--");


    //        //    //}
    //        //    //else
    //        //    //{
    //        //    //    //ddldesignation.DataSource = (new Designation()).getDesignationById(Int32.Parse(ddlLocality.SelectedValue));
    //        //    //    //ddldesignation.DataTextField = "desig_name";
    //        //    //    //ddldesignation.DataValueField = "intDesignationid";
    //        //    //    //ddldesignation.DataBind();



    //        //    //}
    //        //    if (drHeads["intDesignationid"].ToString() != "")
    //        //    {
    //        //        ddldesignation.SelectedValue = drHeads["intDesignationid"].ToString();
    //        //    }
    //        //    if (drHeads["emp_name"].ToString() != "")
    //        //    {
    //        //        txtname.Text = drHeads["emp_name"].ToString();
    //        //    }
    //        //    if (drHeads["mobile_no"].ToString() != "")
    //        //    {
    //        //        txtmobilenumber.Text = drHeads["mobile_no"].ToString();
    //        //    }
    //        //    if (drHeads["email"].ToString() != "")
    //        //    {
    //        //        txtemail.Text = drHeads["email"].ToString();
    //        //    }
    //        //    //if (drHeads["work_from"].ToString() != "")
    //        //    //{
    //        //    //    txtworkingfrom.Text = Convert.ToDateTime(drHeads["work_from"]).ToString("dd-MM-yyyy");
    //        //    //}

    //        //}
    //        //ddlUserlevel.SelectedIndex = 0;
    //        //ddlUserlevel.Enabled = false;
    //        //RequiredFieldValidator10.Enabled = false;
    //        txtuserid.Text = "*******";
    //        txtpwd.TextMode = TextBoxMode.SingleLine;
    //        txtpwd.Text = "******";
    //        txtuserid.Enabled = false;
    //        RequiredFieldValidator8.Enabled = false;

    //        txtpwd.Enabled = false;
    //        RequiredFieldValidator9.Enabled = false;
    //        lblResult.Text = " ";

    //    }
    //    catch (Exception ex)
    //    {
    //        lblResult.Text = ex.ToString();
    //    }
    //    finally
    //    {
    //        con1.CloseConnection();
    //    }
    //}
    //#endregion 

    //#region btnOrgLookup_Click
    //protected void btnOrgLookup_Click(object sender, EventArgs e)
    //{

    //}
    //#endregion

    //#region BtnReset
    //protected void BtnReset_Click(object sender, EventArgs e)
    //{

    //    try
    //    {
    //        Response.Redirect("frmAddEmp.aspx");
    //        txtname.Text = "";
    //        ddldesignation.SelectedIndex = 0;
    //        ddlLocality.SelectedIndex = 0;
    //        txtmobilenumber.Text = "";
    //        txtemail.Text = "";
    //       // txtworkingfrom.Text = "";
    //        BtnSubmit.Text = "Submit";
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //}

    //#endregion 

    //#region ddlLocality_SelectedIndexChanged
    //protected void ddlLocality_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    try
    //    {


    //        if (ddlLocality.SelectedValue == "--Select--")
    //        {
    //            ddldesignation.Items.Clear();
    //            ddldesignation.Items.Insert(0, "--Select--");


    //        }
    //        else
    //        {
    //            //ddldesignation.DataSource = (new Designation()).getDesignationById(Int32.Parse(ddlLocality.SelectedValue));
    //            //ddldesignation.DataTextField = "desig_name";
    //            //ddldesignation.DataValueField = "intDesignationid";
    //            //ddldesignation.DataBind();


    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //}
    //#endregion


    protected void BtnSubmit_Click(object sender, EventArgs e)
    {

    }
    protected void BtnReset_Click(object sender, EventArgs e)
    {

    }
    protected void BtnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmStudentDashboard.aspx");
    }
}

