﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Dashboard : System.Web.UI.Page
{
    //designed by siva as on 29-1-2016 
    //Purpose : Report for Year wise dashboard
    //Tables used : All
    //Stored procedures Used :YearwiseDashboardforAdmin
    
    General Gen = new General();
    protected void Page_Load(object sender, EventArgs e)
    {
                
        //if (Session.Count <= 0)
        //{
        ////    Response.Redirect("../../frmUserLogin.aspx");
        //   // Response.Redirect("~/frmuserlogin.aspx");
        //    Response.Redirect("~/IndexNew.aspx");
        //}

        //if (!IsPostBack)
        //{
        //    FillDetails();
        //}

        if (!IsPostBack)
        {


            FillDetails();


           
        }


     

        
        
    }
   
   
    void FillDetails()
    {


       
            Label4.Text ="0";
            Label21.Text = "0";
            Label12.Text = "0";
            Label3.Text = "0";

            Label6.Text = "0";
            Label1.Text = "0";

       

    }


    protected void BtnSave3_Click(object sender, EventArgs e)
    {

    }
    protected void BtnClosebatchClear1_Click(object sender, EventArgs e)
    {

    }
    protected void ddlCorporation_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlmandal_SelectedIndexChanged(object sender, EventArgs e)
    {
      
        
    }
    protected void BtnClear0_Click(object sender, EventArgs e)
    {
       
    }
    protected void ddlVillage_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    void getHabitations()
    {


    }
    protected void ddlWard3_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
}
