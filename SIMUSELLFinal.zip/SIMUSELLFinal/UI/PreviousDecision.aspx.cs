using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class frmProjectMaster : System.Web.UI.Page
{
    General gen = new General();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session.Count <= 0)
        {
            Response.Redirect("../Login.aspx");
        }
        if (!IsPostBack)
        {
            getDashboardStudent();
           
        }
    }

    void getDashboardStudent()
    {
        DataSet Deatils = new DataSet();

        Deatils = gen.getDashboardStudent(Session["userCode"].ToString().Trim());


        if (Deatils.Tables[0].Rows.Count > 0)
        {
            lblName.Text = Deatils.Tables[0].Rows[0]["Name"].ToString();
            lblTeamName.Text = Deatils.Tables[0].Rows[0]["companyName"].ToString();
            lblSimulationName.Text = Deatils.Tables[0].Rows[0]["simulationName"].ToString();
            lblEmail.Text = Deatils.Tables[0].Rows[0]["email"].ToString();
            lblInstructorName.Text = Deatils.Tables[0].Rows[0]["Insname"].ToString();
        }
        if (Deatils.Tables[0].Rows.Count > 0)
        {
            ddlRounds.DataSource = Deatils.Tables[1];
            ddlRounds.DataTextField = "RoundNo";
            ddlRounds.DataValueField = "simulationRoundId";
            ddlRounds.DataBind();
            ddlRounds.Items.Insert(0, "--Select--");
        }

    }
    void fillDetails()
    {
        DataSet dsnew = new DataSet();

        //dsnew = gen.getslaesforcebyID(Session["userCode"].ToString().Trim());
        dsnew = gen.getSPPDet(Session["userCode"].ToString().Trim(), "%",ddlRounds.SelectedValue);
        if (dsnew.Tables[0].Rows.Count > 0)
        {

            GrdRoundDet.DataSource = dsnew.Tables[0];
            GrdRoundDet.DataBind();



        }
        else
        {
            GrdRoundDet.DataSource = null;
            GrdRoundDet.DataBind();

        }
    }

    protected void btnEdit_Click(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        int i = 0;
        i = gen.insertdatatotdsaleforcedecission(Session["userCode"].ToString().Trim());

        Response.Redirect("frmStudentDashboard.aspx");
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {

    }

    protected void ddlDeptCode_SelectedIndexChanged1(object sender, EventArgs e)
    {

    }
    protected void ddlmandal_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {


    }
    protected void ddlSchemes_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void ddlmandal0_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ddlSchemeYear0_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click1(object sender, EventArgs e)
    {
        Button btnSubmit = (Button)sender;

        GridViewRow row = (GridViewRow)btnSubmit.NamingContainer;

        HiddenField hdfFlagSPID = (HiddenField)row.FindControl("hdfFlagSPID");

        HiddenField hdfFlagSPID0 = (HiddenField)row.FindControl("hdfFlagSPID0");



        Response.Redirect("frmManageEmployee.aspx?mspid=" + hdfFlagSPID.Value + "&Teid=" + hdfFlagSPID0.Value.ToString());

        //int result = gen.updateStatusTerritory(hdfFlagSPID.Value,hdfFlagSPID0.Value, "1000");

        //if (result > 0)
        //{

        //    Response.Redirect("");


        //}




    }
    protected void btnSubmit_Click2(object sender, EventArgs e)
    {
        Button btnSubmit = (Button)sender;

        GridViewRow row = (GridViewRow)btnSubmit.NamingContainer;

        HiddenField hdfFlagSPID = (HiddenField)row.FindControl("hdfFlagSPID");

        HiddenField hdfFlagSPID0 = (HiddenField)row.FindControl("hdfFlagSPID0");



        Response.Redirect("frmManageTerritory.aspx?mspid=" + hdfFlagSPID.Value + "&Teid=" + hdfFlagSPID0.Value.ToString());

        //int result = gen.updateStatusTerritory(hdfFlagSPID.Value,hdfFlagSPID0.Value, "1000");

        //if (result > 0)
        //{

        //    Response.Redirect("");


        //}




    }
    protected void GrdRoundDet_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            LinkButton HypName = (LinkButton)e.Row.Cells[1].FindControl("HypName");

            HypName.Text = "Details";
            HypName.Style.Add("color", "Blue");
            HypName.OnClientClick = "javascript:return Popup('" + Convert.ToString(DataBinder.Eval(e.Row.DataItem, "spID")).Trim() + "','" + ddlRounds.SelectedValue + "')";
           
        }
    }
    
    protected void btnSearch_Click(object sender, EventArgs e)
    {
       
    }
    protected void ddlRounds_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlRounds.SelectedValue != "--Select--")
        {
            fillDetails();
        }
        else
        {
            GrdRoundDet.DataSource = null;
            GrdRoundDet.DataBind();
            lblResult.Text = "Please Select Simulation Round";
        }
    }

    protected void BtnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmStudentDashboard.aspx");
    }
}
