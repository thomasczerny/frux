////****** Designed by Ravichandra on 20-08-2012 *******////
//Stored Procedures:getUserByUserId,saveUserRecord,getAllDept,insertemployee by Balkrishna on 25-9-12
//Last modified by Jyotshna on 28-05-2013

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class UI_frmVehicleSetup : System.Web.UI.Page
{
    #region Declaration
    DB.DB con1 = new DB.DB();
    Employee d = new Employee();
    General gen = new General();
    WMS tran1 = new WMS();
    //DataRow dr;
    //static int id;
    SqlDataReader drHeads = null;
    fruxFunctions fss = new fruxFunctions();
    #endregion

    //Added by Balakrishna on 25-9-12
    int User_Code;

    protected void Page_Load(object sender, EventArgs e)
    {
        //btnOrgLookup.Attributes.Add("onclick", "javascript:return OpenPopup()");
        //lblResult.Text = "";
        if (!Page.IsPostBack)
        {


            filldet();
            //fiildepartment();
        }

    }

    void filldet()
    {


        DataSet dsfill = new DataSet();
        dsfill = gen.GetFilldetlistSPD(Request.QueryString[0].ToString(), Request.QueryString[1].ToString());
        if (dsfill.Tables[0].Rows.Count > 0)
        {
            lblEmployeeName.Text = dsfill.Tables[0].Rows[0]["firstName"].ToString() + " " + dsfill.Tables[0].Rows[0]["lastName"].ToString();
            lblJobTitle.Text = dsfill.Tables[0].Rows[0]["jobTitleDesc"].ToString();
            //     lblDepartment47.Text = "$" + dsfill.Tables[0].Rows[0]["TotalSales"].ToString();
            //    lblDepartment48.Text = dsfill.Tables[0].Rows[0]["experience"].ToString();
            //    lblDepartment49.Text = "$" + dsfill.Tables[0].Rows[0]["NetContribution"].ToString();
            lblDepartment50.Text = "$" + dsfill.Tables[0].Rows[0]["salary"].ToString();
            lblDepartment51.Text = "$" + dsfill.Tables[0].Rows[0]["bonus"].ToString();
            lblDepartment52.Text = dsfill.Tables[0].Rows[0]["commissionPercentage"].ToString();
            lblDepartment53.Text = "$" + dsfill.Tables[0].Rows[0]["EmployeeQuota"].ToString();
            lblDepartment54.Text = dsfill.Tables[0].Rows[0]["totalCompensationSensitivity"].ToString();

            //lblRolePerceptions.Text = dsfill.Tables[0].Rows[0]["competitiveness"].ToString();
            //lblSkillLevel.Text = dsfill.Tables[0].Rows[0]["presentationSkills"].ToString();
            //lblAptitude.Text = dsfill.Tables[0].Rows[0]["highestEducationCompleted"].ToString();
            //lblMotivationLevel.Text = dsfill.Tables[0].Rows[0]["negotiationSkills"].ToString();
            //lblTotalSalesAbilities.Text = dsfill.Tables[0].Rows[0]["productKnowledge"].ToString();
            //lblMotivationLevel.Text = dsfill.Tables[0].Rows[0]["workEthic"].ToString();
            //lblAAccounts.Text = dsfill.Tables[0].Rows[0]["AAccount1"].ToString();
            //lblBAccounts.Text = dsfill.Tables[0].Rows[0]["BAccount1"].ToString();
            //lblCAccounts.Text = dsfill.Tables[0].Rows[0]["CAccount1"].ToString();
            lblRecognition.Text = dsfill.Tables[0].Rows[0]["recognitionType"].ToString();

            lblsupervision.Text = dsfill.Tables[0].Rows[0]["AssignAddSupervision"].ToString();
            lblTraining.Text = dsfill.Tables[0].Rows[0]["AssignTraining"].ToString();
            lblPromotion.Text = dsfill.Tables[0].Rows[0]["GivePromotion"].ToString();
        }

        if (dsfill.Tables[1].Rows.Count > 0)
        {
            grdState.DataSource = dsfill.Tables[1];
            grdState.DataBind();



        }
        else
        {
            grdState.DataSource = null;
            grdState.DataBind();

        }
        if (dsfill.Tables[2].Rows.Count > 0)
        {
            GrdAccounts.DataSource = dsfill.Tables[2];
            GrdAccounts.DataBind();



        }
        else
        {
            GrdAccounts.DataSource = null;
            GrdAccounts.DataBind();

        }


    }

    protected void BtnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmSaleForce.aspx");
    }

    protected void BtnReset_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmManageEmployee.aspx");
    }

    protected void GrdState_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //HiddenField hdfStateID = (HiddenField)e.Row.FindControl("hdfStateID");
            //hdfStateID.Value = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "spID")).Trim();

            //TextBox TxtAAcount = (TextBox)e.Row.FindControl("TxtAAcount");
            //TxtAAcount.Text = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "AAccount")).Trim();
            //TextBox TxtBAcount = (TextBox)e.Row.FindControl("TxtBAcount");
            //TxtBAcount.Text = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "BAccount")).Trim();
            //TextBox TxtCAcount = (TextBox)e.Row.FindControl("TxtCAcount");
            //TxtCAcount.Text = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "CAccount")).Trim();

            Label lblAAcount = (Label)e.Row.FindControl("lblAAcount");
            lblAAcount.Text = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "AAccount")) + "%".Trim();
            Label lblBAcount = (Label)e.Row.FindControl("lblBAcount");
            lblBAcount.Text = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "BAccount")) + "%".Trim();
            Label lblCAcount = (Label)e.Row.FindControl("lblCAcount");
            lblCAcount.Text = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "CAccount")) + "%".Trim();
        }
    }
    protected void TxtAAcount_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TxtBAcount_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TxtCAcount_TextChanged(object sender, EventArgs e)
    {
        //TextBox txt = (TextBox)sender;
        //GridViewRow row = (GridViewRow)GrdAccounts.NamingContainer;
        //TextBox TxtAAcount = (TextBox)row.FindControl("TxtAAcount");
        //TextBox TxtBAcount = (TextBox)row.FindControl("TxtBAcount");
        //TextBox TxtCAcount = (TextBox)row.FindControl("TxtCAcount");

        //int count = (Convert.ToInt32(TxtAAcount.Text) + Convert.ToInt32(TxtBAcount.Text) + Convert.ToInt32(TxtCAcount.Text));

        //if (count > 100 || count < 100)
        //{
        //    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", string.Format("alert('{1}', '{0}');", "A,B And C Account values total should be", Title), true);
        //}

    }
}

